<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title> Riwayat Penyewaan </title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/Riwayat.css">

    </head>

    <body>
        <section class="section">
            <h1 class="Teks-riwayat">Riwayat Penyewaan<h1><br>
                <div class="container">
                    <div class="ini-border">
                        <table class="ini-center-border">
                            <tr>
                                <th>Unit</th>
                                <th>Jenis Warehouse</th>
                                <th>Durasi Sewa</th>
                                <th>Total</th>
                                <th>Status Pembayaran</th>
                            </tr>
                            <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pgn->unit_no); ?></td>
                                <td><?php echo e($pgn->warehouse_name); ?></td>
                                <td><?php echo e($pgn->lama_sewa); ?></td>
                                <td><?php echo e($pgn->total); ?></td>
                                <td><?php echo e($pgn->status); ?></td>
                                <td><a href="/invoice/<?php echo e($pgn->id_invoice); ?>"><button>Detail</button></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
        </section>
    </body>
</html>

<?php echo $__env->make('Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Apple Dev\uas_OS-main\uas_OS-main\resources\views/Riwayat.blade.php ENDPATH**/ ?>