<!doctype html>
<html lang="en">
  <head>
  	<title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="css/styleLogin.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">

	</head>
	<body>
	<section class="ftco-section">
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(Session::get('error')); ?></strong>
            </div>
        <?php endif; ?>
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-12 col-lg-10">
					<div class="wrap d-md-flex">
						<div class="img" style="background-image: url(images/warehouse-3.png);">
			      </div>
						<div class="login-wrap p-4 p-md-5">
			      	<div class="d-flex">
			      		<div class="w-100">
			      			<h3 class="mb-4" style="font-size: 24px">Selamat Datang</h3>
			      		</div>
								
			      	</div>
					<form method="post" action="/loginselesai" class="signin-form">
					<?php echo csrf_field(); ?>
						<div class="form-group mb-3">
			      			<label class="label" for="name">Alamat Email</label>
			      			<input type="text" name ="mail" class="form-control" placeholder="Alamat Email" required>
			      		</div>
		            <div class="form-group mb-3">
		            	<label class="label"  for="password">Kata Sandi</label>
		                <input type="password" name ="pass" class="form-control" placeholder="Kata Sandi" required>
		            </div>
		            <div class="form-group">
                        
                        <input type="submit" class="form-control2 btn btn-outline-primary rounded submit px-3" role="button" value="Masuk"/>

		            </div>
					</form>
		            

		          <p class="text-center">Belum memiliki akun?<span><a href="/Daftar"> Daftar</a></span> </p>
		        </div>
		            </div>
				</div>
			</div>
		</div>
	</section>



	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>
<?php /**PATH D:\Kuliah\Apple Dev\uas_OS-main\uas_OS-main\resources\views//Login.blade.php ENDPATH**/ ?>