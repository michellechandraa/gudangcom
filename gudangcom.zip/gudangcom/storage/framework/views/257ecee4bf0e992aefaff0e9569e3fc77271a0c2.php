<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <link rel="stylesheet" href="css/style.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/dashboard.css">

</head>
<body>


<!-- products section starts  -->
<h1 class="teks-dashboard">Dashboard<h1><br>
<section class="products" id="products">
    <div class="box-container">
    <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">
            <!-- <a href="/DetailProduk/<?php echo e($tampilan->UNIT_NO); ?>"><img src="images/1.jpg" alt=""></a> -->



            <div class="ukuran">
            <a href="/DetailProduk2/<?php echo e($tampilan->UNIT_NO); ?>"><img src="images/<?php echo e($tampilan->UNIT_IMAGE); ?>" alt=""></a>
</div>
 <div class="content">

                <h3><?php echo e($tampilan->PSEWA_NAME); ?></h3>
                <h4><?php echo e($tampilan->UNIT_NO); ?></h4>
                <div class="price">Rp<?php echo e(number_format(($tampilan->PSEWA_PRICEYEAR),2,',','.')); ?>/Tahun</div>

                <!-- <a href="/Keranjang" class="btn">+Keranjang</a> -->
                <a href="/DetailProduk2/<?php echo e($tampilan->UNIT_NO); ?>" class="btn">Beli</a>
            </div>
        </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>
    

</body>
</html>

<?php echo $__env->make('Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('welcome2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Apple Dev\uas_OS-main\uas_OS-main\resources\views/Dashboard2.blade.php ENDPATH**/ ?>