@extends('welcome2')

@section('judul', 'sewa')
