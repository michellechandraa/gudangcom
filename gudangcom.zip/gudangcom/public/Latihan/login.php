<?php
echo "
<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <h2>Login Page</h2>
    <form id='frmLogin' method='post' action='frmHandler2.php'>
        NIM: <input type='text' name='nim' id='nim'><br>
        Fakultas: <input type='text' name='fakultas' id=fakultas'><br>
        <input type='submit' value='Login'>
    </form>
</body>
</html>
";
?>
